
package week_01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_Menu extends JFrame {

    private JButton btn_caesar;
    private JButton btn_vigenere;
    private JButton btn_railfence;
    private JButton btn_playfair;
    private JButton btn_transposition;
    private JButton btn_autokey;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {

        setTitle("LAB 1 - Mã hóa đối xứng cổ điển");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(790, 330));
        setContentPane(panel);

        // TIEU DE
        JLabel lbl_title = new JLabel(
            "LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN"
        );

        lbl_title.setFont(
            new Font("Segoe UI", Font.BOLD, 20)
        );
        lbl_title.setForeground(Color.BLACK);
        lbl_title.setBounds(25, 20, 735, 40);
        panel.add(lbl_title);

        // HUONG DAN
        JLabel lbl_guide = new JLabel(
            "Chọn một bài để mở form tương ứng:"
        );

        lbl_guide.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );
        lbl_guide.setBounds(25, 80, 730, 25);
        panel.add(lbl_guide);

        // HANG 1 - 3 NUT
        btn_caesar = new JButton("1.1 Caesar");
        btn_caesar.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_caesar.setBounds(25, 125, 230, 35);
        panel.add(btn_caesar);

        btn_vigenere = new JButton("1.2 Vigenère");
        btn_vigenere.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_vigenere.setBounds(280, 125, 230, 35);
        panel.add(btn_vigenere);

        btn_railfence = new JButton("1.3 Rail Fence");
        btn_railfence.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_railfence.setBounds(535, 125, 230, 35);
        panel.add(btn_railfence);

        // HANG 2 - 3 NUT
        btn_playfair = new JButton("1.4 Playfair");
        btn_playfair.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_playfair.setBounds(25, 180, 230, 35);
        panel.add(btn_playfair);

        btn_transposition = new JButton(
            "1.5 Transposition"
        );
        btn_transposition.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_transposition.setBounds(280, 180, 230, 35);
        panel.add(btn_transposition);

        btn_autokey = new JButton("1.6 Autokey");
        btn_autokey.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_autokey.setBounds(535, 180, 230, 35);
        panel.add(btn_autokey);

        // GHI CHU
        JLabel lbl_note = new JLabel(
            "Mỗi form mở ra là một cửa sổ riêng; "
            + "đóng form con không làm tắt chương trình."
        );

        lbl_note.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_note.setForeground(Color.DARK_GRAY);
        lbl_note.setBounds(25, 265, 735, 30);
        panel.add(lbl_note);

        // SU KIEN CAESAR
        btn_caesar.addActionListener(
            (ActionEvent evt) -> {
                new frm_Caesar().setVisible(true);
            }
        );

        // SU KIEN VIGENERE
        btn_vigenere.addActionListener(
            (ActionEvent evt) -> {
                new frm_Vigenere().setVisible(true);
            }
        );

        // SU KIEN RAIL FENCE
        btn_railfence.addActionListener(
            (ActionEvent evt) -> {
                new frm_RailFence().setVisible(true);
            }
        );

        // SU KIEN PLAYFAIR
        btn_playfair.addActionListener(
            (ActionEvent evt) -> {
                new frm_Playfair().setVisible(true);
            }
        );

        // SU KIEN TRANSPOSITION
        btn_transposition.addActionListener(
            (ActionEvent evt) -> {
                new frm_Transposition().setVisible(true);
            }
        );

        // SU KIEN AUTOKEY
        btn_autokey.addActionListener(
            (ActionEvent evt) -> {
                new frm_Autokey().setVisible(true);
            }
        );

        pack();
    }

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
            // Giu giao dien mac dinh.
        }

        SwingUtilities.invokeLater(() -> {
            new frm_Menu().setVisible(true);
        });
    }
}
