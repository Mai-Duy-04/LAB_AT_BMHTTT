package week_01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_Playfair extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextArea txt_matrix;
    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JButton btn_matrix;

    private JLabel lbl_status;

    public frm_Playfair() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {

        // CAU HINH CUA SO
        setTitle("Playfair Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(710, 455));
        setContentPane(panel);

        // TIEU DE
        JLabel lbl_title = new JLabel("MẬT MÃ PLAYFAIR");
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setForeground(Color.BLACK);
        lbl_title.setBounds(20, 14, 650, 34);
        panel.add(lbl_title);

        // LABEL PLAINTEXT
        JLabel lbl_plain = new JLabel("Plaintext:");
        lbl_plain.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_plain.setBounds(20, 57, 105, 24);
        panel.add(lbl_plain);

        // O NHAP PLAINTEXT
        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setRows(3);

        JScrollPane scrollPlain = new JScrollPane(txt_plaintext);
        scrollPlain.setBounds(130, 55, 550, 65);
        panel.add(scrollPlain);

        // LABEL KEY
        JLabel lbl_key = new JLabel("Key:");
        lbl_key.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_key.setBounds(20, 135, 105, 25);
        panel.add(lbl_key);

        // O NHAP KEY
        txt_key = new JTextField("KEYWORD");
        txt_key.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt_key.setBounds(130, 135, 155, 25);
        panel.add(txt_key);

        // GOI Y KHOA
        JLabel lbl_hint = new JLabel(
            "Chỉ gồm chữ A-Z, ví dụ KEYWORD"
        );
        lbl_hint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_hint.setForeground(Color.BLACK);
        lbl_hint.setBounds(300, 135, 375, 25);
        panel.add(lbl_hint);

        // LABEL KEY MATRIX
        JLabel lbl_key_matrix = new JLabel("Key Matrix:");
        lbl_key_matrix.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_key_matrix.setBounds(20, 180, 105, 25);
        panel.add(lbl_key_matrix);

        // O HIEN THI MA TRAN 5x5
        txt_matrix = new JTextArea();
        txt_matrix.setEditable(false);
        txt_matrix.setLineWrap(false);
        txt_matrix.setRows(5);
        txt_matrix.setColumns(9);
        txt_matrix.setFont(
            new Font("Monospaced", Font.BOLD, 14)
        );
        txt_matrix.setBackground(Color.WHITE);
        txt_matrix.setForeground(Color.BLACK);

        JScrollPane scrollMatrix = new JScrollPane(txt_matrix);
        scrollMatrix.setBounds(130, 175, 185, 120);
        panel.add(scrollMatrix);

        // NUT GENERATE KEY MATRIX
        btn_matrix = new JButton("Generate Key Matrix");
        btn_matrix.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_matrix.setBounds(330, 175, 190, 29);
        panel.add(btn_matrix);

        // LABEL CIPHERTEXT
        JLabel lbl_cipher = new JLabel("Ciphertext:");
        lbl_cipher.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_cipher.setBounds(20, 316, 105, 24);
        panel.add(lbl_cipher);

        // O NHAP CIPHERTEXT
        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setRows(3);

        JScrollPane scrollCipher = new JScrollPane(txt_ciphertext);
        scrollCipher.setBounds(130, 307, 550, 63);
        panel.add(scrollCipher);

        // NUT ENCRYPT
        btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_encrypt.setBounds(130, 381, 95, 28);
        panel.add(btn_encrypt);

        // NUT DECRYPT
        btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_decrypt.setBounds(235, 381, 95, 28);
        panel.add(btn_decrypt);

        // NUT OPEN CIPHERTEXT FILE
        btn_open = new JButton("Open Ciphertext File");
        btn_open.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_open.setBounds(340, 381, 165, 28);
        panel.add(btn_open);

        // NUT SAVE CIPHERTEXT FILE
        btn_save = new JButton("Save Ciphertext File");
        btn_save.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_save.setBounds(515, 381, 165, 28);
        panel.add(btn_save);

        // DONG TRANG THAI
        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_status.setForeground(Color.BLACK);
        lbl_status.setBounds(130, 420, 550, 25);
        panel.add(lbl_status);

        // SU KIEN ENCRYPT
        btn_encrypt.addActionListener(
            (ActionEvent evt) ->
                btn_encryptActionPerformed(evt)
        );

        // SU KIEN DECRYPT
        btn_decrypt.addActionListener(
            (ActionEvent evt) ->
                btn_decryptActionPerformed(evt)
        );

        // SU KIEN OPEN FILE
        btn_open.addActionListener(
            (ActionEvent evt) ->
                btn_openActionPerformed(evt)
        );

        // SU KIEN SAVE FILE
        btn_save.addActionListener(
            (ActionEvent evt) ->
                btn_saveActionPerformed(evt)
        );

        // SU KIEN GENERATE KEY MATRIX
        btn_matrix.addActionListener(
            (ActionEvent evt) ->
                btn_matrixActionPerformed(evt)
        );

        pack();
    }

    // MA HOA PLAYFAIR
    private void btn_encryptActionPerformed(ActionEvent evt) {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {
            String key = txt_key.getText().trim();

            txt_ciphertext.setText(
                PlayfairCipher.encrypt(plaintext, key)
            );

            lbl_status.setText(
                "Đã mã hóa Playfair (bỏ dấu cách, J -> I, chèn X)."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // GIAI MA PLAYFAIR
    private void btn_decryptActionPerformed(ActionEvent evt) {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {
            String key = txt_key.getText().trim();

            txt_plaintext.setText(
                PlayfairCipher.decrypt(ciphertext, key)
            );

            lbl_status.setText(
                "Đã giải mã Playfair (còn ký tự đệm X)."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // MO FILE CIPHERTEXT
    private void btn_openActionPerformed(ActionEvent evt) {

        String path = FileTextIO.openText(
            this,
            txt_ciphertext
        );

        if (path != null) {
            lbl_status.setText(
                "Đã mở tệp: " + path
            );
        }
    }

    // LUU FILE CIPHERTEXT
    private void btn_saveActionPerformed(ActionEvent evt) {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "playfair_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText(
                "Đã lưu tệp: " + path
            );
        }
    }

    // TAO MA TRAN KHOA 5x5
    private void btn_matrixActionPerformed(ActionEvent evt) {

        try {
            txt_matrix.setText(
                PlayfairCipher.getKeyMatrix(
                    txt_key.getText()
                )
            );

            txt_matrix.setCaretPosition(0);

            lbl_status.setText(
                "Đã tạo ma trận khóa 5x5 (I và J dùng chung ô)."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Khóa không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // CHAY RIENG FORM PLAYFAIR
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
            // Giu giao dien mac dinh.
        }

        SwingUtilities.invokeLater(() -> {
            new frm_Playfair().setVisible(true);
        });
    }
}