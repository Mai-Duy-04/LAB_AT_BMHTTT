
package week_01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_Transposition extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;

    private JLabel lbl_status;

    public frm_Transposition() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {

        // CAU HINH CUA SO
        setTitle("Transposition Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(710, 314));
        setContentPane(panel);

        // TIEU DE
        JLabel lbl_title = new JLabel(
            "MẬT MÃ HOÁN VỊ CỘT (TRANSPOSITION)"
        );
        lbl_title.setFont(
            new Font("Segoe UI", Font.BOLD, 18)
        );
        lbl_title.setForeground(Color.BLACK);
        lbl_title.setBounds(20, 18, 670, 34);
        panel.add(lbl_title);

        // LABEL PLAINTEXT
        JLabel lbl_plain = new JLabel("Plaintext:");
        lbl_plain.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_plain.setBounds(20, 59, 100, 22);
        panel.add(lbl_plain);

        // O NHAP PLAINTEXT
        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setRows(3);

        JScrollPane scrollPlain =
            new JScrollPane(txt_plaintext);
        scrollPlain.setBounds(124, 57, 566, 62);
        panel.add(scrollPlain);

        // LABEL KEY
        JLabel lbl_key = new JLabel("Key:");
        lbl_key.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_key.setBounds(20, 132, 100, 22);
        panel.add(lbl_key);

        // O NHAP KEY
        txt_key = new JTextField("2,3,1");
        txt_key.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        txt_key.setBounds(124, 132, 136, 23);
        panel.add(txt_key);

        // GOI Y KHOA
        JLabel lbl_hint = new JLabel(
            "Thứ tự đọc cột, cách nhau dấu phẩy, ví dụ 2,3,1"
        );
        lbl_hint.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_hint.setForeground(Color.BLACK);
        lbl_hint.setBounds(271, 132, 420, 23);
        panel.add(lbl_hint);

        // LABEL CIPHERTEXT
        JLabel lbl_cipher = new JLabel("Ciphertext:");
        lbl_cipher.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_cipher.setBounds(20, 172, 100, 22);
        panel.add(lbl_cipher);

        // O NHAP CIPHERTEXT
        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(
            new Font("Segoe UI", Font.PLAIN, 13)
        );
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setRows(3);

        JScrollPane scrollCipher =
            new JScrollPane(txt_ciphertext);
        scrollCipher.setBounds(124, 168, 566, 62);
        panel.add(scrollCipher);

        // NUT ENCRYPT
        btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_encrypt.setBounds(124, 245, 98, 27);
        panel.add(btn_encrypt);

        // NUT DECRYPT
        btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_decrypt.setBounds(232, 245, 98, 27);
        panel.add(btn_decrypt);

        // NUT OPEN CIPHERTEXT FILE
        btn_open = new JButton("Open Ciphertext File");
        btn_open.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_open.setBounds(340, 245, 165, 27);
        panel.add(btn_open);

        // NUT SAVE CIPHERTEXT FILE
        btn_save = new JButton("Save Ciphertext File");
        btn_save.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        btn_save.setBounds(515, 245, 175, 27);
        panel.add(btn_save);

        // DONG TRANG THAI
        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setFont(
            new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_status.setForeground(Color.BLACK);
        lbl_status.setBounds(124, 281, 566, 22);
        panel.add(lbl_status);

        // GAN SU KIEN ENCRYPT
        btn_encrypt.addActionListener(
            (ActionEvent evt) ->
                btn_encryptActionPerformed(evt)
        );

        // GAN SU KIEN DECRYPT
        btn_decrypt.addActionListener(
            (ActionEvent evt) ->
                btn_decryptActionPerformed(evt)
        );

        // GAN SU KIEN OPEN FILE
        btn_open.addActionListener(
            (ActionEvent evt) ->
                btn_openActionPerformed(evt)
        );

        // GAN SU KIEN SAVE FILE
        btn_save.addActionListener(
            (ActionEvent evt) ->
                btn_saveActionPerformed(evt)
        );

        pack();
    }

    // MA HOA TRANSPOSITION
    private void btn_encryptActionPerformed(ActionEvent evt) {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {
            int[] key = TranspositionCipher.parseKey(
                txt_key.getText()
            );

            txt_ciphertext.setText(
                TranspositionCipher.encrypt(plaintext, key)
            );

            lbl_status.setText(
                "Đã mã hóa với " + key.length + " cột."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // GIAI MA TRANSPOSITION
    private void btn_decryptActionPerformed(ActionEvent evt) {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {
            int[] key = TranspositionCipher.parseKey(
                txt_key.getText()
            );

            txt_plaintext.setText(
                TranspositionCipher.decrypt(ciphertext, key)
            );

            lbl_status.setText(
                "Đã giải mã với " + key.length + " cột."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // MO FILE CIPHERTEXT
    private void btn_openActionPerformed(ActionEvent evt) {

        String path = FileTextIO.openText(
            this,
            txt_ciphertext
        );

        if (path != null) {
            lbl_status.setText(
                "Đã mở tệp: " + path
            );
        }
    }

    // LUU FILE CIPHERTEXT
    private void btn_saveActionPerformed(ActionEvent evt) {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "transposition_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText(
                "Đã lưu tệp: " + path
            );
        }
    }

    // CHAY RIENG FORM TRANSPOSITION
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
            // Giu giao dien mac dinh neu khong doi duoc.
        }

        SwingUtilities.invokeLater(() -> {
            new frm_Transposition().setVisible(true);
        });
    }
}
