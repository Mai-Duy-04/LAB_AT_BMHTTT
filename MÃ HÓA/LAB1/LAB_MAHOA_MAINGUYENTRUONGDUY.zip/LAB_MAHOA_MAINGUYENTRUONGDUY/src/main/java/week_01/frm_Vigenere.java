package week_01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_Vigenere extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;

    private JLabel lbl_status;

    public frm_Vigenere() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {

        setTitle("Vigenere Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(670, 314));
        setContentPane(panel);

        // TIEU DE
        JLabel lbl_title = new JLabel("MẬT MÃ VIGENÈRE");
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setForeground(Color.BLACK);
        lbl_title.setBounds(20, 18, 570, 34);
        panel.add(lbl_title);

        // PLAINTEXT
        JLabel lbl_plain = new JLabel("Plaintext:");
        lbl_plain.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_plain.setBounds(20, 59, 100, 22);
        panel.add(lbl_plain);

        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setRows(3);

        JScrollPane scrollPlain = new JScrollPane(txt_plaintext);
        scrollPlain.setBounds(124, 57, 526, 62);
        panel.add(scrollPlain);

        // KEY
        JLabel lbl_key = new JLabel("Key:");
        lbl_key.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_key.setBounds(20, 132, 100, 22);
        panel.add(lbl_key);

        txt_key = new JTextField("KEY");
        txt_key.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt_key.setBounds(124, 132, 136, 23);
        panel.add(txt_key);

        JLabel lbl_hint = new JLabel("Chỉ gồm chữ A-Z, ví dụ KEY");
        lbl_hint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_hint.setForeground(Color.BLACK);
        lbl_hint.setBounds(271, 132, 360, 23);
        panel.add(lbl_hint);

        // CIPHERTEXT
        JLabel lbl_cipher = new JLabel("Ciphertext:");
        lbl_cipher.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_cipher.setBounds(20, 172, 100, 22);
        panel.add(lbl_cipher);

        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setRows(3);

        JScrollPane scrollCipher = new JScrollPane(txt_ciphertext);
        scrollCipher.setBounds(124, 168, 526, 62);
        panel.add(scrollCipher);

        // BUTTONS
        btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn_encrypt.setBounds(124, 245, 90, 25);
        panel.add(btn_encrypt);

        btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn_decrypt.setBounds(227, 245, 90, 25);
        panel.add(btn_decrypt);

        btn_open = new JButton("Open Ciphertext File");
        btn_open.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn_open.setBounds(329, 245, 157, 25);
        panel.add(btn_open);

        btn_save = new JButton("Save Ciphertext File");
        btn_save.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn_save.setBounds(497, 245, 153, 25);
        panel.add(btn_save);

        // STATUS
        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_status.setForeground(Color.BLACK);
        lbl_status.setBounds(122, 281, 528, 22);
        panel.add(lbl_status);

        // GAN SU KIEN
        btn_encrypt.addActionListener(
            (ActionEvent evt) -> btn_encryptActionPerformed(evt)
        );

        btn_decrypt.addActionListener(
            (ActionEvent evt) -> btn_decryptActionPerformed(evt)
        );

        btn_open.addActionListener(
            (ActionEvent evt) -> btn_openActionPerformed(evt)
        );

        btn_save.addActionListener(
            (ActionEvent evt) -> btn_saveActionPerformed(evt)
        );

        pack();
    }

    // ENCRYPT
    private void btn_encryptActionPerformed(ActionEvent evt) {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {
            String key = txt_key.getText().trim();

            txt_ciphertext.setText(
                VigenereCipher.encrypt(plaintext, key)
            );

            lbl_status.setText(
                "Đã mã hóa Vigenère với khóa " + key + "."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // DECRYPT
    private void btn_decryptActionPerformed(ActionEvent evt) {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {
            String key = txt_key.getText().trim();

            txt_plaintext.setText(
                VigenereCipher.decrypt(ciphertext, key)
            );

            lbl_status.setText(
                "Đã giải mã Vigenère với khóa " + key + "."
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // OPEN FILE
    private void btn_openActionPerformed(ActionEvent evt) {

        String path = FileTextIO.openText(
            this, txt_ciphertext
        );

        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    // SAVE FILE
    private void btn_saveActionPerformed(ActionEvent evt) {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "vigenere_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    // CHAY RIENG FORM
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
            // Giu giao dien mac dinh.
        }

        SwingUtilities.invokeLater(() -> {
            new frm_Vigenere().setVisible(true);
        });
    }
}