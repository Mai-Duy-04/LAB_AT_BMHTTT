USE master;
GO

IF SUSER_ID(N'lab2_user') IS NULL
BEGIN
    CREATE LOGIN lab2_user
    WITH PASSWORD = 'LabUser@2026',
    CHECK_POLICY = ON;
END;
GO

USE LAB2_MaHoaHienDai;
GO

IF DATABASE_PRINCIPAL_ID(N'lab2_user') IS NULL
BEGIN
    CREATE USER lab2_user FOR LOGIN lab2_user;
END;
GO

IF IS_ROLEMEMBER(N'db_datareader', N'lab2_user') = 0
BEGIN
    ALTER ROLE db_datareader ADD MEMBER lab2_user;
END;

IF IS_ROLEMEMBER(N'db_datawriter', N'lab2_user') = 0
BEGIN
    ALTER ROLE db_datawriter ADD MEMBER lab2_user;
END;
GO