package week_02;

import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class frm_AES extends JFrame {

    private String currentUser = null;

    private JTextField txt_username;
    private JPasswordField txt_password;
    private JTextField txt_ticket;
    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JLabel lbl_status;

    public frm_AES() {
        initComponents();
    }

    private void initComponents() {

        setTitle("AES Cipher - Register / Login");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(760, 850);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        setContentPane(panel);

        JLabel lbl_title = new JLabel(
                "AES-GCM - ĐĂNG KÝ / ĐĂNG NHẬP (SQL SERVER)",
                JLabel.CENTER
        );
        lbl_title.setFont(new Font("Arial", Font.BOLD, 21));
        lbl_title.setBounds(40, 20, 660, 45);
        panel.add(lbl_title);

        JLabel lbl_username = new JLabel("Username:");
        lbl_username.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_username.setBounds(45, 85, 120, 30);
        panel.add(lbl_username);

        txt_username = new JTextField("sinhvien01");
        txt_username.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_username.setBounds(165, 85, 300, 32);
        panel.add(txt_username);

        JLabel lbl_password = new JLabel("Password:");
        lbl_password.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_password.setBounds(45, 130, 120, 30);
        panel.add(lbl_password);

        txt_password = new JPasswordField();
        txt_password.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_password.setBounds(165, 130, 300, 32);
        panel.add(txt_password);

        JLabel lbl_passwordHint = new JLabel("(ít nhất 8 ký tự)");
        lbl_passwordHint.setFont(new Font("Arial", Font.ITALIC, 12));
        lbl_passwordHint.setBounds(480, 130, 170, 30);
        panel.add(lbl_passwordHint);

        JButton btn_sql = new JButton("Kết nối SQL Server");
        btn_sql.setBounds(45, 185, 200, 38);
        panel.add(btn_sql);

        JButton btn_register = new JButton("Register");
        btn_register.setBounds(270, 185, 170, 38);
        panel.add(btn_register);

        JButton btn_login = new JButton("Login");
        btn_login.setBounds(465, 185, 170, 38);
        panel.add(btn_login);

        JLabel lbl_ticket = new JLabel("Ticket:");
        lbl_ticket.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_ticket.setBounds(45, 245, 100, 30);
        panel.add(lbl_ticket);

        txt_ticket = new JTextField();
        txt_ticket.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_ticket.setEditable(false);
        txt_ticket.setBounds(165, 245, 470, 32);
        panel.add(txt_ticket);

        JLabel lbl_plaintext = new JLabel("Plaintext:");
        lbl_plaintext.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_plaintext.setBounds(45, 300, 120, 30);
        panel.add(lbl_plaintext);

        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);

        JScrollPane scrollPlaintext = new JScrollPane(txt_plaintext);
        scrollPlaintext.setBounds(45, 335, 650, 100);
        panel.add(scrollPlaintext);

        JLabel lbl_key = new JLabel("Key AES:");
        lbl_key.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_key.setBounds(45, 455, 120, 30);
        panel.add(lbl_key);

        txt_key = new JTextField();
        txt_key.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_key.setBounds(165, 455, 470, 32);
        panel.add(txt_key);

        JLabel lbl_keyHint = new JLabel(
                "Mật khẩu để tạo khóa AES-256"
        );
        lbl_keyHint.setFont(new Font("Arial", Font.ITALIC, 12));
        lbl_keyHint.setForeground(new Color(80, 80, 80));
        lbl_keyHint.setBounds(165, 490, 400, 22);
        panel.add(lbl_keyHint);

        JLabel lbl_ciphertext = new JLabel("Ciphertext:");
        lbl_ciphertext.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_ciphertext.setBounds(45, 525, 120, 30);
        panel.add(lbl_ciphertext);

        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);

        JScrollPane scrollCiphertext = new JScrollPane(txt_ciphertext);
        scrollCiphertext.setBounds(45, 560, 650, 100);
        panel.add(scrollCiphertext);

        JButton btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setBounds(45, 680, 145, 40);
        panel.add(btn_encrypt);

        JButton btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setBounds(210, 680, 145, 40);
        panel.add(btn_decrypt);

        JButton btn_save = new JButton("Save File");
        btn_save.setBounds(375, 680, 145, 40);
        panel.add(btn_save);

        JButton btn_open = new JButton("Open File");
        btn_open.setBounds(540, 680, 155, 40);
        panel.add(btn_open);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setFont(new Font("Arial", Font.PLAIN, 13));
        lbl_status.setBounds(45, 735, 650, 45);
        panel.add(lbl_status);

        btn_sql.addActionListener(e -> {
            new frm_KetNoiSQL().setVisible(true);
        });

        btn_register.addActionListener(e -> registerUser());

        btn_login.addActionListener(e -> loginUser());

        btn_encrypt.addActionListener(e -> encryptText());

        btn_decrypt.addActionListener(e -> decryptText());

        btn_save.addActionListener(e -> saveFile());

        btn_open.addActionListener(e -> openFile());
    }

    private void registerUser() {

        try {

            String user = txt_username.getText().trim();

            UserDao.register(
                    user,
                    txt_password.getPassword()
            );

            HistoryDao.tryInsert(
                    "AES",
                    "REGISTER",
                    user,
                    0,
                    0
            );

            lbl_status.setText(
                    "Register thành công: "
                    + user
                    + ". Bấm Login để đăng nhập."
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi SQL Server: " + ex.getMessage(),
                    "Lỗi SQL Server",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loginUser() {

        currentUser = null;
        txt_ticket.setText("");

        try {

            String user = txt_username.getText().trim();

            if (UserDao.login(
                    user,
                    txt_password.getPassword()
            )) {

                currentUser = user;

                txt_ticket.setText(
                        UserDao.newTicket()
                );

                HistoryDao.tryInsert(
                        "AES",
                        "LOGIN",
                        user,
                        0,
                        0
                );

                lbl_status.setText(
                        "Login thành công: "
                        + user
                        + ". Có thể dùng Encrypt/Decrypt."
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Sai username hoặc mật khẩu.",
                        "Login thất bại",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Lỗi SQL Server: " + ex.getMessage(),
                    "Lỗi SQL Server",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void encryptText() {

        if (currentUser == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy Login trước khi dùng AES."
            );

            return;
        }

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa."
            );

            return;
        }

        try {

            String ciphertext = AESCipher.encrypt(
                    plaintext,
                    txt_key.getText()
            );

            txt_ciphertext.setText(ciphertext);

            lbl_status.setText(
                    "<html>Đã mã hóa AES. "
                    + HistoryDao.tryInsert(
                            "AES",
                            "ENCRYPT",
                            currentUser,
                            plaintext.length(),
                            ciphertext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void decryptText() {

        if (currentUser == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy Login trước khi dùng AES."
            );

            return;
        }

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã."
            );

            return;
        }

        try {

            String plaintext = AESCipher.decrypt(
                    ciphertext,
                    txt_key.getText()
            );

            txt_plaintext.setText(plaintext);

            lbl_status.setText(
                    "<html>Đã giải mã AES. "
                    + HistoryDao.tryInsert(
                            "AES",
                            "DECRYPT",
                            currentUser,
                            ciphertext.length(),
                            plaintext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n"
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void saveFile() {

        String path = FileTextIO.saveText(
                this,
                txt_ciphertext,
                "aes_ciphertext.txt"
        );

        if (path != null) {

            lbl_status.setText(
                    "Đã lưu tệp: " + path
            );
        }
    }

    private void openFile() {

        String path = FileTextIO.openText(
                this,
                txt_ciphertext
        );

        if (path != null) {

            lbl_status.setText(
                    "Đã mở tệp: " + path
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new frm_AES().setVisible(true);
        });
    }
}