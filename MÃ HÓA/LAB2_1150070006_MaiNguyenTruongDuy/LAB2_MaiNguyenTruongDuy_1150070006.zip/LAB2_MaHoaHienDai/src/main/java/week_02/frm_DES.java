
package week_02;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_DES extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_save;
    private JButton btn_open;
    private JButton btn_sql;
    private JButton btn_history;

    private JLabel lbl_status;
    private JLabel lbl_sql_status;

    public frm_DES() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {

        setTitle("DES Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(680, 575));
        setContentPane(panel);

        JLabel lbl_title = new JLabel("MẬT MÃ DES");
        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl_title.setBounds(40, 20, 570, 34);
        panel.add(lbl_title);

        JLabel lbl_plaintext = new JLabel("Plaintext:");
        lbl_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_plaintext.setBounds(40, 65, 120, 25);
        panel.add(lbl_plaintext);

        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setRows(3);

        JScrollPane scrollPlaintext = new JScrollPane(txt_plaintext);
        scrollPlaintext.setBounds(40, 95, 600, 80);
        panel.add(scrollPlaintext);

        JLabel lbl_key = new JLabel("Key:");
        lbl_key.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_key.setBounds(40, 195, 100, 25);
        panel.add(lbl_key);

        txt_key = new JTextField("12345678");
        txt_key.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_key.setBounds(120, 195, 280, 30);
        panel.add(txt_key);

        JLabel lbl_key_note = new JLabel(
                "Đúng 8 ký tự không dấu (8 byte)"
        );
        lbl_key_note.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_key_note.setBounds(410, 195, 230, 30);
        panel.add(lbl_key_note);

        JLabel lbl_ciphertext = new JLabel("Ciphertext:");
        lbl_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_ciphertext.setBounds(40, 245, 120, 25);
        panel.add(lbl_ciphertext);

        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setRows(3);

        JScrollPane scrollCiphertext = new JScrollPane(txt_ciphertext);
        scrollCiphertext.setBounds(40, 275, 600, 80);
        panel.add(scrollCiphertext);

        btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setBounds(40, 380, 120, 35);
        panel.add(btn_encrypt);

        btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setBounds(175, 380, 120, 35);
        panel.add(btn_decrypt);

        btn_save = new JButton("Save File");
        btn_save.setBounds(310, 380, 145, 35);
        panel.add(btn_save);

        btn_open = new JButton("Open File");
        btn_open.setBounds(470, 380, 170, 35);
        panel.add(btn_open);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbl_status.setBounds(40, 425, 600, 40);
        panel.add(lbl_status);

        btn_sql = new JButton("Kết nối SQL");
        btn_sql.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn_sql.setBounds(40, 480, 155, 35);
        panel.add(btn_sql);

        btn_history = new JButton("Xem lịch sử");
        btn_history.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn_history.setBounds(210, 480, 155, 35);
        panel.add(btn_history);

        lbl_sql_status = new JLabel("SQL: Chưa kết nối");
        lbl_sql_status.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_sql_status.setBounds(385, 480, 255, 35);
        panel.add(lbl_sql_status);

        btn_encrypt.addActionListener(evt -> encrypt());
        btn_decrypt.addActionListener(evt -> decrypt());
        btn_save.addActionListener(evt -> saveFile());
        btn_open.addActionListener(evt -> openFile());

        btn_sql.addActionListener(evt -> {
            new frm_KetNoiSQL().setVisible(true);
        });

        btn_history.addActionListener(evt -> {
            new frm_LichSu().setVisible(true);
        });

        javax.swing.Timer timer = new javax.swing.Timer(
                500,
                evt -> updateSqlStatus()
        );
        timer.start();

        pack();
    }

    private void updateSqlStatus() {
        if (DbConfig.isReady()) {
            lbl_sql_status.setText("SQL: Đã kết nối cấu hình");
            lbl_sql_status.setForeground(new Color(0, 115, 50));
        } else {
            lbl_sql_status.setText("SQL: Chưa kết nối");
            lbl_sql_status.setForeground(new Color(160, 40, 40));
        }
    }

    private void encrypt() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {
            String ciphertext = DESCipher.encrypt(
                    plaintext,
                    txt_key.getText()
            );

            txt_ciphertext.setText(ciphertext);

            lbl_status.setText(
                    "<html>Đã mã hóa DES. "
                    + HistoryDao.tryInsert(
                            "DES",
                            "ENCRYPT",
                            null,
                            plaintext.length(),
                            ciphertext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void decrypt() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {
            String plaintext = DESCipher.decrypt(
                    ciphertext,
                    txt_key.getText()
            );

            txt_plaintext.setText(plaintext);

            lbl_status.setText(
                    "<html>Đã giải mã DES. "
                    + HistoryDao.tryInsert(
                            "DES",
                            "DECRYPT",
                            null,
                            ciphertext.length(),
                            plaintext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n"
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void saveFile() {

        String path = FileTextIO.saveText(
                this,
                txt_ciphertext,
                "des_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    private void openFile() {

        String path = FileTextIO.openText(
                this,
                txt_ciphertext
        );

        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
        }

        SwingUtilities.invokeLater(() -> {
            new frm_DES().setVisible(true);
        });
    }
}
