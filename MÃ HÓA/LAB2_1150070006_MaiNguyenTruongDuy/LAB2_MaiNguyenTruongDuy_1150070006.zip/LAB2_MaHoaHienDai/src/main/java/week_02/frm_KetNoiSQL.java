package week_02;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_KetNoiSQL extends JFrame {

    private JTextField txt_server;
    private JTextField txt_port;
    private JTextField txt_database;
    private JTextField txt_user;
    private JPasswordField txt_password;

    private JButton btn_test;
    private JButton btn_history;
    private JLabel lbl_status;

    public frm_KetNoiSQL() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {

        setTitle("Kết nối Microsoft SQL Server");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(610, 440));
        setContentPane(panel);

        JLabel lbl_title = new JLabel(
                "KẾT NỐI MICROSOFT SQL SERVER"
        );
        lbl_title.setFont(
                new Font("Segoe UI", Font.BOLD, 18)
        );
        lbl_title.setBounds(30, 20, 550, 34);
        panel.add(lbl_title);

        JLabel lbl_server = new JLabel("Server:");
        lbl_server.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_server.setBounds(40, 80, 110, 25);
        panel.add(lbl_server);

        txt_server = new JTextField("127.0.0.1");
        txt_server.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_server.setBounds(165, 80, 370, 28);
        panel.add(txt_server);

        JLabel lbl_port = new JLabel("Port:");
        lbl_port.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_port.setBounds(40, 125, 110, 25);
        panel.add(lbl_port);

        txt_port = new JTextField("14333");
        txt_port.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_port.setBounds(165, 125, 140, 28);
        panel.add(txt_port);

        JLabel lbl_database = new JLabel("Database:");
        lbl_database.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_database.setBounds(40, 170, 110, 25);
        panel.add(lbl_database);

        txt_database = new JTextField("LAB2_MaHoaHienDai");
        txt_database.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_database.setBounds(165, 170, 370, 28);
        panel.add(txt_database);

        JLabel lbl_user = new JLabel("User:");
        lbl_user.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_user.setBounds(40, 215, 110, 25);
        panel.add(lbl_user);

        txt_user = new JTextField("lab2_user");
        txt_user.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_user.setBounds(165, 215, 370, 28);
        panel.add(txt_user);

        JLabel lbl_password = new JLabel("Password:");
        lbl_password.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl_password.setBounds(40, 260, 110, 25);
        panel.add(lbl_password);

        txt_password = new JPasswordField();
        txt_password.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt_password.setBounds(165, 260, 370, 28);
        panel.add(txt_password);

        btn_test = new JButton("Test Connection");
        btn_test.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn_test.setBounds(165, 315, 165, 35);
        panel.add(btn_test);

        btn_history = new JButton("Xem lịch sử");
        btn_history.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn_history.setBounds(345, 315, 190, 35);
        panel.add(btn_history);

        lbl_status = new JLabel("Chưa kết nối.");
        lbl_status.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbl_status.setForeground(Color.BLACK);
        lbl_status.setBounds(165, 365, 410, 50);
        panel.add(lbl_status);

        btn_test.addActionListener(
                (ActionEvent evt) ->
                        btn_testActionPerformed(evt)
        );

        btn_history.addActionListener(
                (ActionEvent evt) ->
                        btn_historyActionPerformed(evt)
        );

        pack();
    }

    private void btn_testActionPerformed(ActionEvent evt) {

        try {
            int port = Integer.parseInt(txt_port.getText().trim());

            DbConfig.set(
                    txt_server.getText().trim(),
                    port,
                    txt_database.getText().trim(),
                    txt_user.getText().trim(),
                    txt_password.getPassword()
            );

            lbl_status.setText(
                    "<html>" + DbConfig.test() + "</html>"
            );

        } catch (Exception ex) {

            DbConfig.clear();

            lbl_status.setText(
                    "<html>Kết nối thất bại: "
                    + ex.getMessage() + "</html>"
            );

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Không kết nối được SQL Server",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void btn_historyActionPerformed(ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
        }

        SwingUtilities.invokeLater(() -> {
            new frm_KetNoiSQL().setVisible(true);
        });
    }
}
