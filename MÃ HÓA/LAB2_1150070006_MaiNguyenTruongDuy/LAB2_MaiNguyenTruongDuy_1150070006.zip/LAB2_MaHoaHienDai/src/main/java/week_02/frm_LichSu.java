package week_02;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frm_LichSu extends JFrame {

    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {
        initComponents();
        setLocationRelativeTo(null);
        tbl_history.setModel(HistoryDao.emptyModel());
        loadData();
    }

    private void initComponents() {

        setTitle("Lịch sử thao tác (SQL Server)");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        panel.setPreferredSize(new Dimension(850, 430));
        setContentPane(panel);

        JLabel lbl_title = new JLabel(
                "LỊCH SỬ THAO TÁC - BẢNG DBO.CRYPTO_HISTORY"
        );
        lbl_title.setFont(
                new Font("Segoe UI", Font.BOLD, 18)
        );
        lbl_title.setForeground(Color.BLACK);
        lbl_title.setBounds(25, 20, 800, 35);
        panel.add(lbl_title);

        tbl_history = new JTable();
        tbl_history.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );
        tbl_history.setRowHeight(25);
        tbl_history.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );
        tbl_history.setAutoResizeMode(
                JTable.AUTO_RESIZE_ALL_COLUMNS
        );
        tbl_history.setFillsViewportHeight(true);

        JScrollPane scrollHistory =
                new JScrollPane(tbl_history);

        scrollHistory.setBounds(25, 75, 800, 265);
        panel.add(scrollHistory);

        btn_refresh = new JButton("Tải lại");
        btn_refresh.setFont(
                new Font("Segoe UI", Font.PLAIN, 13)
        );
        btn_refresh.setBounds(25, 355, 110, 30);
        panel.add(btn_refresh);

        lbl_status = new JLabel("Đang tải...");
        lbl_status.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );
        lbl_status.setBounds(155, 350, 670, 45);
        panel.add(lbl_status);

        btn_refresh.addActionListener(
                (ActionEvent evt) ->
                        btn_refreshActionPerformed(evt)
        );

        pack();
    }

    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));

            lbl_status.setText(
                    "Đã tải " + tbl_history.getRowCount()
                    + " dòng mới nhất từ dbo.crypto_history."
            );

        } catch (java.sql.SQLException ex) {
            lbl_status.setText(
                    "Không đọc được lịch sử: " + ex.getMessage()
            );
        }
    }

    private void btn_refreshActionPerformed(ActionEvent evt) {
        loadData();
    }

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception ex) {
        }

        SwingUtilities.invokeLater(() -> {
            new frm_LichSu().setVisible(true);
        });
    }
}
