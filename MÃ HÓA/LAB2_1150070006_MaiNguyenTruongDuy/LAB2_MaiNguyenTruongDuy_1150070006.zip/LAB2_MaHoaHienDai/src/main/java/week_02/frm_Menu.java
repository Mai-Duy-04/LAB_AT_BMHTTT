package week_02;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class frm_Menu extends JFrame {

    public frm_Menu() {
        initComponents();
    }

    private void initComponents() {

        setTitle("LAB 2 - Mã hóa đối xứng hiện đại");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1080, 470);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        setContentPane(panel);

        JLabel lbl_title = new JLabel(
                "LAB 2 - MÃ HÓA ĐỐI XỨNG HIỆN ĐẠI"
        );
        lbl_title.setFont(
                new Font("Segoe UI", Font.BOLD, 30)
        );
        lbl_title.setForeground(Color.BLACK);
        lbl_title.setBounds(32, 28, 950, 48);
        panel.add(lbl_title);

        JLabel lbl_guide = new JLabel(
                "Chọn một bài để mở form tương ứng:"
        );
        lbl_guide.setFont(
                new Font("Segoe UI", Font.PLAIN, 17)
        );
        lbl_guide.setBounds(32, 100, 950, 28);
        panel.add(lbl_guide);

        JButton btn_des = new JButton("2.1 DES");
        btn_des.setBounds(35, 155, 310, 43);
        panel.add(btn_des);

        JButton btn_tripledes = new JButton("2.2 TripleDES");
        btn_tripledes.setBounds(365, 155, 310, 43);
        panel.add(btn_tripledes);

        JButton btn_aes = new JButton("2.3 AES + Login");
        btn_aes.setBounds(695, 155, 310, 43);
        panel.add(btn_aes);

        JButton btn_rc4 = new JButton("2.4 RC4");
        btn_rc4.setBounds(35, 223, 310, 43);
        panel.add(btn_rc4);

        JButton btn_twofish = new JButton("2.5 Twofish");
        btn_twofish.setBounds(365, 223, 310, 43);
        panel.add(btn_twofish);

        JButton btn_aesctr = new JButton(
                "2.6 Nâng cao - AES-CTR"
        );
        btn_aesctr.setBounds(695, 223, 310, 43);
        btn_aesctr.setEnabled(false);
        btn_aesctr.setToolTipText(
                "Bài nâng cao không thực hiện"
        );
        panel.add(btn_aesctr);

        JButton btn_sql = new JButton("Kết nối SQL Server");
        btn_sql.setBounds(35, 290, 310, 43);
        panel.add(btn_sql);

        JButton btn_history = new JButton("Xem lịch sử");
        btn_history.setBounds(365, 290, 310, 43);
        panel.add(btn_history);

        JLabel lbl_python = new JLabel(
                "Bài nâng cao 02 (AES-CBC) viết bằng Python: chạy tệp aes_cbc_gui.py."
        );
        lbl_python.setFont(
                new Font("Segoe UI", Font.PLAIN, 16)
        );
        lbl_python.setBounds(32, 355, 980, 30);
        panel.add(lbl_python);

        btn_des.addActionListener(e -> {
            new frm_DES().setVisible(true);
        });

        btn_tripledes.addActionListener(e -> {
            new frm_TripleDES().setVisible(true);
        });

        btn_aes.addActionListener(e -> {
            new frm_AES().setVisible(true);
        });

        btn_rc4.addActionListener(e -> {
            new frm_RC4().setVisible(true);
        });

        btn_twofish.addActionListener(e -> {
            new frm_Twofish().setVisible(true);
        });

        btn_sql.addActionListener(e -> {
            new frm_KetNoiSQL().setVisible(true);
        });

        btn_history.addActionListener(e -> {
            new frm_LichSu().setVisible(true);
        });
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new frm_Menu().setVisible(true);
        });
    }
}