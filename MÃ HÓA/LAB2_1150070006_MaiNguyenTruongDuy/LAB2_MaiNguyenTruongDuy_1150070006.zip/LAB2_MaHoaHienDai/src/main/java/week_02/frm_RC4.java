package week_02;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class frm_RC4 extends JFrame {

    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JLabel lbl_status;

    public frm_RC4() {
        initComponents();
    }

    private void initComponents() {

        setTitle("RC4 Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(720, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        setContentPane(panel);

        JLabel lbl_title = new JLabel(
                "MẬT MÃ DÒNG RC4",
                JLabel.CENTER
        );
        lbl_title.setFont(new Font("Arial", Font.BOLD, 23));
        lbl_title.setBounds(80, 20, 540, 40);
        panel.add(lbl_title);

        JLabel lbl_plaintext = new JLabel("Plaintext:");
        lbl_plaintext.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_plaintext.setBounds(40, 80, 120, 25);
        panel.add(lbl_plaintext);

        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);

        JScrollPane scrollPlaintext = new JScrollPane(txt_plaintext);
        scrollPlaintext.setBounds(40, 110, 620, 100);
        panel.add(scrollPlaintext);

        JLabel lbl_key = new JLabel("Key:");
        lbl_key.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_key.setBounds(40, 225, 100, 25);
        panel.add(lbl_key);

        txt_key = new JTextField("Key");
        txt_key.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_key.setBounds(110, 225, 550, 32);
        panel.add(txt_key);

        JLabel lbl_hint = new JLabel(
                "1 - 256 byte; bản mã hiển thị dạng HEX"
        );
        lbl_hint.setFont(new Font("Arial", Font.ITALIC, 12));
        lbl_hint.setForeground(new Color(80, 80, 80));
        lbl_hint.setBounds(110, 260, 550, 20);
        panel.add(lbl_hint);

        JLabel lbl_ciphertext = new JLabel("Ciphertext:");
        lbl_ciphertext.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_ciphertext.setBounds(40, 295, 120, 25);
        panel.add(lbl_ciphertext);

        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);

        JScrollPane scrollCiphertext = new JScrollPane(txt_ciphertext);
        scrollCiphertext.setBounds(40, 325, 620, 100);
        panel.add(scrollCiphertext);

        JButton btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setBounds(40, 445, 145, 38);
        panel.add(btn_encrypt);

        JButton btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setBounds(200, 445, 145, 38);
        panel.add(btn_decrypt);

        JButton btn_save = new JButton("Save File");
        btn_save.setBounds(360, 445, 145, 38);
        panel.add(btn_save);

        JButton btn_open = new JButton("Open File");
        btn_open.setBounds(520, 445, 140, 38);
        panel.add(btn_open);

        JButton btn_sql = new JButton("Kết nối SQL");
        btn_sql.setBounds(150, 500, 180, 38);
        panel.add(btn_sql);

        JButton btn_history = new JButton("Xem lịch sử");
        btn_history.setBounds(370, 500, 180, 38);
        panel.add(btn_history);

        lbl_status = new JLabel("Trạng thái: Sẵn sàng.");
        lbl_status.setFont(new Font("Arial", Font.PLAIN, 12));
        lbl_status.setBounds(40, 555, 620, 35);
        panel.add(lbl_status);

        btn_encrypt.addActionListener(e -> encryptText());
        btn_decrypt.addActionListener(e -> decryptText());
        btn_save.addActionListener(e -> saveFile());
        btn_open.addActionListener(e -> openFile());

        btn_sql.addActionListener(e -> {
            new frm_KetNoiSQL().setVisible(true);
        });

        btn_history.addActionListener(e -> {
            new frm_LichSu().setVisible(true);
        });
    }

    private void encryptText() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa."
            );
            return;
        }

        try {

            String ciphertext = RC4Cipher.encrypt(
                    plaintext,
                    txt_key.getText()
            );

            txt_ciphertext.setText(ciphertext);

            lbl_status.setText(
                    "<html>Đã mã hóa RC4. "
                    + HistoryDao.tryInsert(
                            "RC4",
                            "ENCRYPT",
                            null,
                            plaintext.length(),
                            ciphertext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void decryptText() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã."
            );
            return;
        }

        try {

            String plaintext = RC4Cipher.decrypt(
                    ciphertext,
                    txt_key.getText()
            );

            txt_plaintext.setText(plaintext);

            lbl_status.setText(
                    "<html>Đã giải mã RC4. "
                    + HistoryDao.tryInsert(
                            "RC4",
                            "DECRYPT",
                            null,
                            ciphertext.length(),
                            plaintext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại:\n" + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void saveFile() {

        String path = FileTextIO.saveText(
                this,
                txt_ciphertext,
                "rc4_ciphertext.txt"
        );

        if (path != null) {
            lbl_status.setText("Đã lưu tệp: " + path);
        }
    }

    private void openFile() {

        String path = FileTextIO.openText(
                this,
                txt_ciphertext
        );

        if (path != null) {
            lbl_status.setText("Đã mở tệp: " + path);
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new frm_RC4().setVisible(true);
        });
    }
}