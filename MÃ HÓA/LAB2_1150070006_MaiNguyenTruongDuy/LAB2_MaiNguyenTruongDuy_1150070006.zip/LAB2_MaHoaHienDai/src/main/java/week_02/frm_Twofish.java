package week_02;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class frm_Twofish extends JFrame {

    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextField txt_iv;
    private JTextArea txt_ciphertext;
    private JLabel lbl_status;

    public frm_Twofish() {
        initComponents();
    }

    private void initComponents() {

        setTitle("Twofish Cipher");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(760, 730);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 217, 223));
        setContentPane(panel);

        JLabel lbl_title = new JLabel(
                "MẬT MÃ TWOFISH (CBC)",
                JLabel.CENTER
        );
        lbl_title.setFont(new Font("Arial", Font.BOLD, 23));
        lbl_title.setBounds(80, 20, 580, 40);
        panel.add(lbl_title);

        JLabel lbl_plaintext = new JLabel("Plaintext:");
        lbl_plaintext.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_plaintext.setBounds(40, 80, 120, 25);
        panel.add(lbl_plaintext);

        txt_plaintext = new JTextArea();
        txt_plaintext.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);

        JScrollPane scrollPlaintext = new JScrollPane(txt_plaintext);
        scrollPlaintext.setBounds(40, 110, 660, 100);
        panel.add(scrollPlaintext);

        JLabel lbl_key = new JLabel("Key:");
        lbl_key.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_key.setBounds(40, 225, 100, 25);
        panel.add(lbl_key);

        txt_key = new JTextField("Twofish@Lab2");
        txt_key.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_key.setBounds(120, 225, 580, 32);
        panel.add(txt_key);

        JLabel lbl_keyHint = new JLabel(
                "Mật khẩu bất kỳ (khóa = SHA-256)"
        );
        lbl_keyHint.setFont(new Font("Arial", Font.ITALIC, 12));
        lbl_keyHint.setForeground(new Color(80, 80, 80));
        lbl_keyHint.setBounds(120, 260, 500, 20);
        panel.add(lbl_keyHint);

        JLabel lbl_iv = new JLabel("IV (HEX):");
        lbl_iv.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_iv.setBounds(40, 295, 100, 25);
        panel.add(lbl_iv);

        txt_iv = new JTextField();
        txt_iv.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_iv.setBounds(140, 295, 390, 32);
        panel.add(txt_iv);

        JButton btn_iv = new JButton("Generate IV");
        btn_iv.setBounds(545, 295, 155, 32);
        panel.add(btn_iv);

        JLabel lbl_ciphertext = new JLabel("Ciphertext:");
        lbl_ciphertext.setFont(new Font("Arial", Font.BOLD, 14));
        lbl_ciphertext.setBounds(40, 350, 120, 25);
        panel.add(lbl_ciphertext);

        txt_ciphertext = new JTextArea();
        txt_ciphertext.setFont(new Font("Arial", Font.PLAIN, 14));
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);

        JScrollPane scrollCiphertext = new JScrollPane(txt_ciphertext);
        scrollCiphertext.setBounds(40, 380, 660, 100);
        panel.add(scrollCiphertext);

        JButton btn_encrypt = new JButton("Encrypt");
        btn_encrypt.setBounds(40, 500, 150, 38);
        panel.add(btn_encrypt);

        JButton btn_decrypt = new JButton("Decrypt");
        btn_decrypt.setBounds(210, 500, 150, 38);
        panel.add(btn_decrypt);

        JButton btn_save = new JButton("Save File");
        btn_save.setBounds(380, 500, 150, 38);
        panel.add(btn_save);

        JButton btn_open = new JButton("Open File");
        btn_open.setBounds(550, 500, 150, 38);
        panel.add(btn_open);

        JButton btn_sql = new JButton("Kết nối SQL");
        btn_sql.setBounds(170, 555, 180, 38);
        panel.add(btn_sql);

        JButton btn_history = new JButton("Xem lịch sử");
        btn_history.setBounds(390, 555, 180, 38);
        panel.add(btn_history);

        lbl_status = new JLabel("Trạng thái: Sẵn sàng.");
        lbl_status.setFont(new Font("Arial", Font.PLAIN, 12));
        lbl_status.setBounds(40, 615, 660, 45);
        panel.add(lbl_status);

        btn_iv.addActionListener(e -> generateIV());

        btn_encrypt.addActionListener(e -> encryptText());

        btn_decrypt.addActionListener(e -> decryptText());

        btn_save.addActionListener(e -> saveFile());

        btn_open.addActionListener(e -> openFile());

        btn_sql.addActionListener(e -> {
            new frm_KetNoiSQL().setVisible(true);
        });

        btn_history.addActionListener(e -> {
            new frm_LichSu().setVisible(true);
        });
    }

    private void generateIV() {

        txt_iv.setText(TwofishCipher.newIv());

        lbl_status.setText(
                "Đã tạo IV ngẫu nhiên 16 byte. "
                + "Giữ nguyên IV này để giải mã."
        );
    }

    private void encryptText() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Plaintext trước khi mã hóa."
            );

            return;
        }

        try {

            String ciphertext = TwofishCipher.encrypt(
                    plaintext,
                    txt_key.getText(),
                    txt_iv.getText()
            );

            txt_ciphertext.setText(ciphertext);

            lbl_status.setText(
                    "<html>Đã mã hóa Twofish. "
                    + HistoryDao.tryInsert(
                            "Twofish",
                            "ENCRYPT",
                            null,
                            plaintext.length(),
                            ciphertext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Mã hóa thất bại:\n" + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void decryptText() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Hãy nhập Ciphertext trước khi giải mã."
            );

            return;
        }

        try {

            String plaintext = TwofishCipher.decrypt(
                    ciphertext,
                    txt_key.getText(),
                    txt_iv.getText()
            );

            txt_plaintext.setText(plaintext);

            lbl_status.setText(
                    "<html>Đã giải mã Twofish. "
                    + HistoryDao.tryInsert(
                            "Twofish",
                            "DECRYPT",
                            null,
                            ciphertext.length(),
                            plaintext.length()
                    )
                    + "</html>"
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Dữ liệu không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Giải mã thất bại: sai Key hoặc bản mã bị sửa.\n"
                    + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void saveFile() {

        if (txt_ciphertext.getText().isBlank()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Chưa có bản mã để lưu."
            );

            return;
        }

        String content = TwofishCipher.toFile(
                txt_iv.getText(),
                txt_ciphertext.getText()
        );

        String path = FileTextIO.saveString(
                this,
                content,
                "twofish_ciphertext.txt"
        );

        if (path != null) {

            lbl_status.setText(
                    "Đã lưu IV + bản mã vào: " + path
            );
        }
    }

    private void openFile() {

        String content = FileTextIO.openString(this);

        if (content == null) {
            return;
        }

        try {

            String[] parts = TwofishCipher.fromFile(content);

            txt_iv.setText(parts[0]);

            txt_ciphertext.setText(parts[1]);

            lbl_status.setText(
                    "Đã mở tệp, khôi phục IV và bản mã. "
                    + "Nhập đúng Key rồi bấm Decrypt."
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Tệp không hợp lệ",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new frm_Twofish().setVisible(true);
        });
    }
}